package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/*
 * Project name:JDBC Console projrct
 * Description:The main purpose of this projcet
 * is to explore JDBC apis for performing DML operation 
 */

public class JDBCProject {

	public static void main(String[] args) {
//		Dao.createTable();
		//Dao.insertTable("zebra", 30000);
	//	Dao.updateTable(1, 50000);
		//Dao.ReadTable();
		Dao.deleteTable(3);
  Scanner s=new Scanner(System.in);
  int option=0;
  do {
	  System.out.println("---choose correct option---" );
	  System.out.println("1:crate the table");
	  System.out.println("2:insert the table");
	  System.out.println("3:update the table");
	  System.out.println("4:read the table");
	  System.out.println("5:delete the table");
	  System.out.println("6:exite the table");
	  switch(option) {
	  case 1:
		  if(option==1) {
			  Dao.createTable();
			  
		  }else {
			  System.out.println("Table created once");
		  }
		  break;
	  case 2:
		  System.out.println("enter the name and salary");
		  String name=s.next();
		  int salery=s.nextInt();
		  System.out.println(name);
		  System.out.println(salery);
		  Dao.insertTable(name, salery);
		  
	  break;
	  case 3:
		  System.out.println("enter the id to update the table");
		  int id=s.nextInt();
		  int salery1=s.nextInt();
		  Dao.updateTable(id, salery1);
		  break;
	  case 4:
		  System.out.println("read tha all deatails");
		  Dao.ReadTable();
		  break;
	  case 5:
		  System.out.println("enter the id delete record");
		  int id1=s.nextInt();
		  Dao.deleteTable(id1);
		 break;
	  case 0:
		  System.out.println("exite the table");
	  }	  

  }while(option!=0);
	}
}

class Dao{
	/*DAO:data access object:used to communicate with da
	 * 
	 * 
	 */
	public static void createTable() {
		Connection c=null;
		Statement s=null;
		try {
			//class used to load the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
        c=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance","root","Rachana@2003");
		 //url:says url is in my local system
		 s=c.createStatement();
		//statement:used execute the query
		//we createstatement bec staticquery
		 
		 s.executeUpdate("create table stud(id int primary key Auto_Increment,name varchar(30),salery int)");
		  System.out.println("table crated succesfully");
		} catch (ClassNotFoundException e) {
			System.out.println("driver is not properly loaded");
		
			e.printStackTrace();
		}catch(SQLException e) {
			System.out.println("somethig went wrong databse");
		
			e.printStackTrace();
		}finally {
			
				try {
					if(s!=null) 
					s.close();
					if(c!=null)
						c.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
		}
	public static void insertTable(String name,int salery ) {
		Connection c=null;
		PreparedStatement p=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
        c=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance","root","Rachana@2003");
		 p=c.prepareStatement("insert into stud (name,salery)values(?,?) ");
		 p.setString(1, name);
		 p.setInt(2, salery);
		 p.executeUpdate();
		 System.out.println("record inserted succefully");
		} catch (ClassNotFoundException e) {
			//e is the erroir variable
			System.out.println(e.getCause());
			/*
			 * get the exact root cause & error msg
			 */
			System.out.println(e.getMessage());
			//we get the exact information of the exception of the root cause
			System.out.println("driver is not properly loaded");
		
			e.printStackTrace();
		}catch(SQLException e) {
			System.out.println("somethig went wrong databse");
		
			e.printStackTrace();
		}catch(Exception e) {
			/*it is the good practice write like that bec we didn't know the 
			 * exception name it handle all thing
			 * 
			 */
			
			System.out.println("something unsual thing happen");
		}
		finally {
			
				try {
					if(p!=null) 
					p.close();
					if(c!=null)
						c.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
	}

	public static void updateTable(int id,int salery ) {
		Connection c=null;
		PreparedStatement p=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
        c=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance","root","Rachana@2003");
		 p=c.prepareStatement("update stud set salery=? where id=? ");
		 //"UPDATE stud SET salary=? WHERE id=?" 
		 p.setInt(1, salery);
		  p.setInt(2, id);
		 p.executeUpdate();
		 System.out.println("table updated");
		} catch (ClassNotFoundException e) {
			//e is the erroir variable
			System.out.println(e.getCause());
			/*
			 * get the exact root cause & error msg
			 */
			System.out.println(e.getMessage());
			//we get the exact information of the exception of the root cause
			System.out.println("driver is not properly loaded");
		
			e.printStackTrace();
		}catch(SQLException e) {
			System.out.println("somethig went wrong databse");
		
			e.printStackTrace();
		}catch(Exception e) {
			/*it is the good practice write like that bec we didn't know the 
			 * exception name it handle all thing
			 * 
			 */
			
			System.out.println("something unsual thing happen");
		}
		finally {
			
				try {
					if(p!=null) 
					p.close();
					if(c!=null)
						c.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
	}


	public static void ReadTable( ) {
		Connection c=null;
		Statement s=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
        c=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance","root","Rachana@2003");
		 s=c.createStatement();
		 //"UPDATE stud SET salary=? WHERE id=?" 
		
		 ResultSet res=s.executeQuery("select * from stud");
		 while(res.next())
			 System.out.println(res.getInt(1)+" "+res.getString(2)+" "+res.getInt(3));
		System.out.println("read the table data");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getCause());
			
			System.out.println(e.getMessage());
			System.out.println("driver is not properly loaded");
		
			e.printStackTrace();
		}catch(SQLException e) {
			System.out.println("somethig went wrong databse");
		
			e.printStackTrace();
		}catch(Exception e) {
			
			
			System.out.println("something unsual thing happen");
		}
		finally {
			
				try {
					if(s!=null) 
					s.close();
					if(c!=null)
						c.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
	}
	public static void deleteTable(int id) {
		Connection c=null;
		PreparedStatement p=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
        c=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance","root","Rachana@2003");
		 p=c.prepareStatement("delete from stud where id=? ");
		 p.setInt(1, id);
		 
		 p.executeUpdate();
		 System.out.println("delete the data is done!");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getCause());
			
			System.out.println(e.getMessage());
			System.out.println("driver is not properly loaded");
		
			e.printStackTrace();
		}catch(SQLException e) {
			System.out.println("somethig went wrong databse");
		
			e.printStackTrace();
		}catch(Exception e) {
			
			
			System.out.println("something unsual thing happen");
		}
		finally {
			
				try {
					if(p!=null) 
					p.close();
					if(c!=null)
						c.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
	}


}

